$(document).ready(function () {
    $('a.menu_class').click(function () {
	$('ul.the_menu').slideToggle('medium');
    });
});